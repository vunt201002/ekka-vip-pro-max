
<?php $__env->startSection('title', 'Giỏ hàng'); ?>

<?php $__env->startSection('css'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row ec_breadcrumb_inner">
                        <div class="col-md-6 col-sm-12">
                            <h2 class="ec-breadcrumb-title">Đăng ký</h2>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <ul class="ec-breadcrumb-list">
                                <li class="ec-breadcrumb-item"><a href="">Trang chủ</a></li>
                                <li class="ec-breadcrumb-item active">Đăng ký</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <section class="ec-page-content section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title">
                        <h2 class="ec-bg-title">Đăng kí thành viên</h2>
                        <h2 class="ec-title">Đăng kí thành viên</h2>
                    </div>
                </div>
                <div class="ec-register-wrapper">
                    <div class="ec-register-container">
                        <div class="ec-register-form">
                            <form action="<?php echo e(route('customer.register')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <span class="ec-register-wrap ec-register-half">
                                    <label>Họ và tên*</label>
                                    <input type="text" name="name" placeholder="Họ và tên" required />
                                </span>
                                <span class="ec-register-wrap ec-register-half">
                                    <label>Email*</label>
                                    <input type="email" name="email" placeholder="Email..." required />
                                </span>
                                <span class="ec-register-wrap ec-register-half">
                                    <label>Số điện thoại*</label>
                                    <input type="text" name="phone" placeholder=" Số điện thoại"
                                        required />
                                </span>
                                <span class="ec-register-wrap ec-register-half">
                                    <label>Mật khẩu*</label>
                                    <input type="password" name="password" placeholder="password"
                                        required />
                                </span>
                                <span class="ec-register-wrap ec-register-btn">
                                    <button class="btn btn-primary" type="submit">Đăng kí</button>
                                </span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sub_layout'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backend-data\ekka\resources\views/customer/register.blade.php ENDPATH**/ ?>