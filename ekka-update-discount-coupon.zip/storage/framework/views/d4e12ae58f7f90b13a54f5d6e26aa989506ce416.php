<div class="notification-group top-right" id="notification-sending"></div>
<div class="notification-group top-right" id="notification-success"></div>
<div class="notification-group top-right" id="notification-error"></div><?php /**PATH D:\Backend-data\ekka\resources\views/admin/toast.blade.php ENDPATH**/ ?>