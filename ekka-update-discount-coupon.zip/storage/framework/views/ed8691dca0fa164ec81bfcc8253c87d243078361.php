
<?php $__env->startSection('title', 'Giỏ hàng'); ?>

<?php $__env->startSection('css'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row ec_breadcrumb_inner">
                        <div class="col-md-6 col-sm-12">
                            <h2 class="ec-breadcrumb-title">Đăng nhập</h2>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <ul class="ec-breadcrumb-list">
                                <li class="ec-breadcrumb-item"><a href="/">Trang chủ</a></li>
                                <li class="ec-breadcrumb-item active">Đăng nhập</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="ec-page-content section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title">
                        <h2 class="ec-bg-title">Đăng nhập</h2>
                        <h2 class="ec-title">Đăng nhập</h2>
                        <p class="sub-title mb-3">Đăng nhập để xem tiến trình giao hàng</p>
                    </div>
                </div>
                <div class="ec-login-wrapper">
                    <div class="ec-login-container">
                        <div class="ec-login-form">
                            <?php if( Session::has('error_login') ): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(Session::get('error_login')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if( Session::has('success_logout') ): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(Session::get('success_logout')); ?>

                                </div>
                            <?php endif; ?>
                            <form  action="<?php echo e(route('customer.login')); ?>" method="post">
                            	<?php echo csrf_field(); ?>
                                <span class="ec-login-wrap">
                                    <label>Email*</label>
                                    <input type="text" name="email" placeholder="Email" required />
                                </span>
                                <span class="ec-login-wrap">
                                    <label>Mật khẩu*</label>
                                    <input type="password" name="password" placeholder="Mật khẩu" required />
                                </span>
                                <a href="/forgot" style="margin-left: auto;">Quên mật khẩu</a>
                                <span class="ec-login-wrap ec-login-btn">
                                    <button class="btn btn-primary" type="submit">Đăng nhập</button>
                                    <a href="register" class="btn btn-secondary">Đăng kí</a>
                                </span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sub_layout'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backend-data\ekka defauld\resources\views/customer/auth.blade.php ENDPATH**/ ?>